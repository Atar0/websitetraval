<html>
<body>

Welcome <?php echo $_GET["location"]; ?><br>
Your email address is: <?php echo $_GET["location"]; ?>

</body>
</html>